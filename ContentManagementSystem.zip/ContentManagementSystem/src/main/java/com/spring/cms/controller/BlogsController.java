/**
 * 
 */
package com.spring.cms.controller;

/**
 * @author M1028078
 *
 */
public class BlogsController {

}
