package com.spring.cms.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "blogs")
public class BlogsEntity {

	private int blogsId;
	private String blogsName;
	private String description;
	private Date createdDate;
	private List<BlogsAttachmentEntity> blogsAttachment = new ArrayList<BlogsAttachmentEntity>();
	private List<BlogsCommentEntity> blogsComment = new ArrayList<BlogsCommentEntity>();
	private String uploadedBy;
	
	/**
	 * @return the blogsId
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getBlogsId() {
		return this.blogsId;
	}
	/**
	 * @param blogsId the blogsId to set
	 */
	public void setBlogsId(int blogsId) {
		this.blogsId = blogsId;
	}
	/**
	 * @return the blogsName
	 */
	public String getBlogsName() {
		return this.blogsName;
	}
	/**
	 * @param blogsName the blogsName to set
	 */
	public void setBlogsName(String blogsName) {
		this.blogsName = blogsName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the blogsAttachment
	 */
	@OneToMany(mappedBy = "blogs", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	public List<BlogsAttachmentEntity> getBlogsAttachment() {
		return this.blogsAttachment;
	}
	/**
	 * @param blogsAttachment the blogsAttachment to set
	 */
	public void setBlogsAttachment(List<BlogsAttachmentEntity> blogsAttachment) {
		this.blogsAttachment = blogsAttachment;
	}
	/**
	 * @return the blogsComment
	 */
	@OneToMany(mappedBy = "blogs", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public List<BlogsCommentEntity> getBlogsComment() {
		return this.blogsComment;
	}
	/**
	 * @param blogsComment the blogsComment to set
	 */
	public void setBlogsComment(List<BlogsCommentEntity> blogsComment) {
		this.blogsComment = blogsComment;
	}
	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return this.uploadedBy;
	}
	/**
	 * @param uploadedBy the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

}
