package com.spring.cms.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "blogs_attachment")
public class BlogsAttachmentEntity {

	private int attachmentId;
	private String attachmentPath;
	private BlogsEntity blogs;
	
	/**
	 * @return the attachmentId
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getAttachmentId() {
		return this.attachmentId;
	}
	/**
	 * @param attachmentId the attachmentId to set
	 */
	public void setAttachmentId(int attachmentId) {
		this.attachmentId = attachmentId;
	}
	/**
	 * @return the attachmentPath
	 */
	public String getAttachmentPath() {
		return this.attachmentPath;
	}
	/**
	 * @param attachmentPath the attachmentPath to set
	 */
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	/**
	 * @return the blogs
	 */
	@ManyToOne
	@JoinColumn(name = "blogs_id")
	public BlogsEntity getBlogs() {
		return this.blogs;
	}
	/**
	 * @param blogs the blogs to set
	 */
	public void setBlogs(BlogsEntity blogs) {
		this.blogs = blogs;
	}

}
