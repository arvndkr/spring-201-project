/**
 * 
 */
package com.spring.cms.dao;

/**
 * @author M1028078
 *
 */
public class BlogsDaoImpl implements BlogsDao {

}
