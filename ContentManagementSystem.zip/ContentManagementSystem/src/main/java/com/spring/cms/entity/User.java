package com.spring.cms.entity;

public class User {

}
