/**
 * 
 */
package com.spring.cms.service;

/**
 * @author M1028078
 *
 */
public interface BlogsService {

}
