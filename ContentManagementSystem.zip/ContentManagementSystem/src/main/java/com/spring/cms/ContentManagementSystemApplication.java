package com.spring.cms;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;

@SpringBootApplication
@ComponentScan(basePackages = "com.spring.cms")
public class ContentManagementSystemApplication  extends SpringBootServletInitializer  {

	public static void main(String[] args) {
		SpringApplication.run(ContentManagementSystemApplication.class, args);
	}
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder app) {
		return app.sources(ContentManagementSystemApplication.class);
		} 
	
	
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) {
        //ApplicationLoggerUtil.info(this.getClass(), "Session factory initialization started");
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		/*sessionBuilder.addAnnotatedClasses(UserEntity.class);
		sessionBuilder.addAnnotatedClasses(HotelEntity.class);*/
		
		//ApplicationLoggerUtil.info(this.getClass(), "Session factory initialized");
		return sessionBuilder.buildSessionFactory();
	}
	
	
	
}
