/**
 * 
 */
package com.spring.cms.dao;

/**
 * @author M1028078
 *
 */
public interface BlogsDao {

}
