/**
 * 
 */
package com.spring.cms.service;

/**
 * @author M1028078
 *
 */
public class BlogsServiceImpl implements BlogsService {

}
