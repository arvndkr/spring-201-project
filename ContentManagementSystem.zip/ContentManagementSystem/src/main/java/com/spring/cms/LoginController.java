package com.spring.cms;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/*import com.hotelManagement.dao.UserDao;
import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.exception.HotelBookingServiceException;
import com.hotelManagement.service.UserRegistrationService;
import com.hotelManagement.validator.HotelBookingValidator;
import com.hotelManagement.validator.RegistrationValidator;*/


/**
 * This class handles request coming from home and register pages.
 * @author Gaurav
 *
 */
@Controller
public class LoginController {/*

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UserDao userDaoImpl;
	
	@Autowired
	private UserRegistrationService userRegistrationervice;
	
	@Autowired
	private RegistrationValidator registrationValidator;;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(registrationValidator);
	}

	*//**
	 * This method redirects to login page.
	 * @return
	 *//*
	@RequestMapping(value="/")
	public ModelAndView getHomePage() {
		logger.info("--Accessing login page--");
		return new ModelAndView("login");
	}

	*//**
	 * This method redirects to login page.
	 * @param error
	 * @param logout
	 * @param model
	 * @param request
	 * @return
	 *//*
	@RequestMapping("/authenticate")
	public ModelAndView getLoginPage(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout, Model model,HttpServletRequest request) {
		if (error != null) {
			logger.info("--Invalid Username or Password--");
			model.addAttribute("error", "Invalid username and password");
		}

		if (logout != null) {
			logger.info("--Logging out--");
			request.getSession().invalidate();
			model.addAttribute("msg", "You've been logged out successfully.");
		}
		return new ModelAndView("login");
	}
	
	*//**
	 * This method logout scenario.
	 * @param request
	 * @param response
	 * @return
	 *//*
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, HttpServletResponse response) {
		logger.info("--logging out--");
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		    if (auth != null){    
		    	logger.info("--Accessing authentication obj--"+auth);
		        new SecurityContextLogoutHandler().logout(request, response, auth);
		    }
		return "redirect:/authenticate?logout";
	}
	
	*//**
	 * This method redirects to register page.
	 * @param model
	 * @return
	 *//*
	@RequestMapping("/register")
	public ModelAndView redirectToRegisterPage(Model model) {
		try {
			model.addAttribute("cities",userRegistrationervice.fetchAllCities());
		} catch (HotelBookingServiceException e) {
			logger.error("##error occured while fetching cities##");
			return new ModelAndView("exception");
		}
		logger.info("--Redirecting to register page--");
		model.addAttribute("userReg",new UserRegistrationDto());
		return new ModelAndView("register");
	}
	
	*//**
	 * This method submit registration.
	 * @param userRegistrationDto
	 * @param bindingResult
	 * @param model
	 * @return
	 *//*
	@RequestMapping("/submitRegstration")
	public ModelAndView submitRegstration(@ModelAttribute("userReg")@Validated UserRegistrationDto userRegistrationDto,BindingResult bindingResult, Model model) {
		if(bindingResult.hasErrors()){
			logger.error("##Validator :: errors## "+bindingResult.getErrorCount());
			try {
				model.addAttribute("cities",userRegistrationervice.fetchAllCities());
			} catch (HotelBookingServiceException e) {
				logger.error("## error occured while fetching cities ## ");
			}
			return new ModelAndView("register");
		}
		try {
			userRegistrationervice.submitRegistration(userRegistrationDto);
		} catch (HotelBookingServiceException e) {
			logger.error("## error occured while submitting registration ##");
			return new ModelAndView("exception");
		}
		model.addAttribute("success","Congratulations!!! You have been successfully registered to BookMyRoom.com.");
		return new ModelAndView("register");
	}

	*//**
	 * This method redirects to home page.
	 * @param model
	 * @return
	 *//*
	@RequestMapping("/home")
	public ModelAndView home(Model model) {
		User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		logger.info("--user name--"+user.getUsername());
		model.addAttribute("userName",user.getUsername());
		return new ModelAndView("home");
	}
	
*/}
