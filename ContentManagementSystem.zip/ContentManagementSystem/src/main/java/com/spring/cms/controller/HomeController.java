/**
 * 
 */
package com.spring.cms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author M1028078
 *
 */
@Controller
public class HomeController {

	@RequestMapping(value = "/home", method = {
			RequestMethod.GET, RequestMethod.POST })
	public String viewHomePage(Model model){
		System.out.println("in asa home");
		return "index";
	}
	
	/*@RequestMapping(value = {"/error"})
	public String errorPage(){
		System.out.println("Error page");
		return "home";
	}*/
}
