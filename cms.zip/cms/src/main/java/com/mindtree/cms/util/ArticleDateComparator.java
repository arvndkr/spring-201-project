/**
 * 
 */
package com.mindtree.cms.util;

import java.util.Comparator;

import com.mindtree.cms.entity.Article;

/**
 * @author Sumit Verma
 *  this cmparator will sort the article list based on creation
 *         date, descending order.
 */
public class ArticleDateComparator implements Comparator<Article> {

	@Override
	public int compare(Article o1, Article o2) {
		return o2.getCreatedDate().compareTo(o1.getCreatedDate());
	}

}
