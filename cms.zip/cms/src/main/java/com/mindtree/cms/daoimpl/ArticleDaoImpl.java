/**
 * 
 */
package com.mindtree.cms.daoimpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.mindtree.cms.controllers.ArticleController;
import com.mindtree.cms.controllers.HomeController;
import com.mindtree.cms.dao.ArticleDao;
import com.mindtree.cms.dto.ArticleDto;
import com.mindtree.cms.entity.Article;
import com.mindtree.cms.entity.ArticleAttachment;
import com.mindtree.cms.entity.ArticleComment;
import com.mindtree.cms.exception.CmsDaoException;
import com.mindtree.cms.exception.CmsServiceException;
import com.mindtree.cms.util.ArticleDateComparator;
import com.mindtree.cms.util.CmsHibernateUtil;
import com.mindtree.cms.util.CommentComparator;

/**
 * @author Sumit Verma
 *
 */
@Repository
public class ArticleDaoImpl extends CmsHibernateUtil implements ArticleDao {

	private static final Logger logger = LoggerFactory
			.getLogger(ArticleDaoImpl.class);

	/**
	 * this method will update the article.
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mindtree.cms.dao.ArticleDao#updateArticle(int)
	 */
	@Override
	public void updateArticle(int articleId, String updatedName,
			String updatedDescription) throws CmsDaoException {

		Session session = getSession();
		try {

			Article article = (Article) session.load(Article.class, articleId);
			if (article != null) {

				article.setArticleName(updatedName);
				article.setDescription(updatedDescription);
				session.saveOrUpdate(article);
			}
		} catch (HibernateException e) {
			throw new CmsDaoException("can not update the artice because:" + e,
					e);
		} finally {
			session.flush();
			session.close();
		}
	}

	/**
	 * this method will save the new article created by user.
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.mindtree.cms.dao.ArticleDao#saveArticle(com.mindtree.cms.dto.ArticleDto
	 * , java.util.List)
	 */
	@Override
	public boolean saveArticle(ArticleDto dto, List<String> filePaths)
			throws CmsDaoException {
		boolean flag = false;
		Article article = new Article();
		article.setArticleName(dto.getArticleName());
		article.setDescription(dto.getArticleDescription());
		article.setCreatedDate(dto.getCreatedDate());
		article.setUploadedBy(dto.getCreatedBy());
		Session session = getSession();
		try {
			session.save(article);
			for (String path : filePaths) {
				ArticleAttachment articleAttachment = new ArticleAttachment();
				articleAttachment.setFilePath(path);
				articleAttachment.setArticle(article);
				session.save(articleAttachment);
			}
			flag= true;
		} catch (HibernateException e) {
			throw new CmsDaoException("Can not save artice", e);
		} finally {
			session.flush();
			session.close();
		}
		return flag;
	}

	/**
	 * this method will delete the selected article.
	 */
	@Override
	public void deleteArticle(int articleId) throws CmsDaoException {
		Session session = getSession();
		try {

			Article article = (Article) session.load(Article.class, articleId);
			if (article != null) {

				session.delete(article);
			}
		} catch (HibernateException e) {
			throw new CmsDaoException("Could not delete", e);
		}

		finally {
			session.flush();
			session.close();
		}

	}

	/**
	 * this method will get all the articles from the database.
	 */
	@Override
	public List<Article> getArticles() throws CmsDaoException {

		Session session = getSession();
		List<Article> articles = null;
		try {
			Query query = session.createQuery("from Article");
			articles = new ArrayList<Article>();
			articles = query.list();
			Collections.sort(articles, new ArticleDateComparator());
		} catch (HibernateException e) {
			throw new CmsDaoException("could not get articles list", e);
		} finally {
			session.flush();
			session.close();
		}
		return articles;

	}

	/**
	 * this method will get the details of selected article.
	 */
	@Override
	public Article getArticle(int articleId) throws CmsDaoException {
		Session session = getSession();
		Article article = null;
		try {
			article = (Article) session.get(Article.class, articleId);
			List<ArticleComment> articleComments = article.getArticleComments();
			Collections.sort(articleComments, new CommentComparator());
			article.setArticleComments(articleComments);
		} catch (HibernateException e) {
			throw new CmsDaoException("could not fetch article details", e);
		} finally {
			session.flush();
			session.close();
		}
		return article;
	}

	/**
	 * this metihod will save comment given to one article
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.mindtree.cms.dao.ArticleDao#saveComment(com.mindtree.cms.entity.
	 * ArticleComment)
	 */
	@Override
	public void saveComment(ArticleComment comment, int articleId)
			throws CmsDaoException {

		ArticleComment articleComment = comment;
		Session session = getSession();
		try {
			Article article = (Article) session.get(Article.class, articleId);
			if (article != null) {

				articleComment.setArticle(article);
				session.save(articleComment);
				session.flush();
			}
		} catch (HibernateException e) {
			throw new CmsDaoException("Exception occured while saving comment",
					e);
		} finally {
			session.flush();
			session.close();
		}

	}

}
