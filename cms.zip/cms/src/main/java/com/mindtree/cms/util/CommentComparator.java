/**
 * 
 */
package com.mindtree.cms.util;

import java.util.Comparator;

import com.mindtree.cms.entity.ArticleComment;

/**
 * @author Sumit Verma 
 * this comparator will sort the comments date wise, descending
 *         order.
 */
public class CommentComparator implements Comparator<ArticleComment> {

	@Override
	public int compare(ArticleComment o1, ArticleComment o2) {
		return o2.getCreatedDate().compareTo(o1.getCreatedDate());
	}

}
