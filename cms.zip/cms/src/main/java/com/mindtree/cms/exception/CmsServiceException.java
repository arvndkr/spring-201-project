/**
 * 
 */
package com.mindtree.cms.exception;

/**
 * @author Sumit Verma
 *
 */
public class CmsServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public CmsServiceException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CmsServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public CmsServiceException(String message) {
		super(message);
	}

}
