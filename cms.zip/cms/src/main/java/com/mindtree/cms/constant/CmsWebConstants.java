/**
 * 
 */
package com.mindtree.cms.constant;

/**
 * @author Sumit Verma
 *
 */
public interface CmsWebConstants {
	
	Object NULL = null;

}
