/**
 * 
 */
package com.mindtree.cms.controllers;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.cms.dto.ArticleDto;
import com.mindtree.cms.entity.Article;
import com.mindtree.cms.entity.ArticleComment;
import com.mindtree.cms.exception.CmsServiceException;
import com.mindtree.cms.service.ArticleService;
import com.mindtree.cms.util.CmsFileUploadUtil;

/**
 * @author Sumit Verma
 *
 */

@Controller
public class ArticleController implements ServletContextAware {

	private static final Logger logger = LoggerFactory
			.getLogger(HomeController.class);

	@Autowired
	private ArticleService articleService;

	@Autowired
	private CmsFileUploadUtil fileUtil;

	ServletContext sc;

	@RequestMapping(value = "uploadArticle")
	public String uploadContent(
			@ModelAttribute("multipleFiles") ArticleDto articleDto,
			Model model, Principal principal, HttpServletRequest request) {

		List<MultipartFile> cmsFiles = articleDto.getMultipleAttachement();
		List<String> filePath = new ArrayList<String>();
		String rootPath = request.getSession().getServletContext()
				.getRealPath("/");
		filePath = fileUtil.saveFiles(cmsFiles, filePath, rootPath);

		Date date = new Date();
		articleDto.setCreatedDate(date);
		String uploadedBy = principal.getName();
		articleDto.setCreatedBy(uploadedBy);
		try {
			boolean isSave= articleService.saveArticle(articleDto, filePath);
			if(isSave){
				model.addAttribute("isUploaded", "yes");
			}else{
				if(!isSave){
					
					model.addAttribute("isUploadedWithoutAttach", "yes");
				}
			}
		} catch (CmsServiceException e) {
			model.addAttribute("isUploaded", "no");
			logger.info("exception occured , can not save the artice");
		}
		

		return "uploadArticle";
	}

	@RequestMapping(value = "getArticles")
	public String getArticles(Model model, HttpServletRequest request) {
		System.out.println(sc.getContextPath());
		List<Article> list = null;
		;
		try {
			list = articleService.getArticles();
		} catch (CmsServiceException e) {

			logger.error(e.getMessage());
		}
		model.addAttribute("list", list);
		model.addAttribute("baseUrl", getBaseURL(request));
		return "viewArticles";
	}

	@RequestMapping(value = "getArticle/{id}")
	public String getArticle(Model model, @PathVariable("id") int articleId,
			HttpServletRequest request) {
		System.out.println(sc.getContextPath());
		Article article = null;
		try {
			article = articleService.getArticle(articleId);
		} catch (CmsServiceException e) {
			logger.error(e.getMessage());
		}
		model.addAttribute("article", article);
		ArticleComment ac = new ArticleComment();
		ArticleDto articleDto = new ArticleDto();
		ac.setArticle(new Article());
		model.addAttribute("articleComment", ac);
		model.addAttribute("articleNew", articleDto);
		model.addAttribute("baseUrl", getBaseURL(request));
		return "viewArticle";
	}

	@RequestMapping(value = "editArticle/{id}")
	public String editArticle(Model model, @PathVariable("id") int articleId,
			HttpServletRequest request) {
		System.out.println(sc.getContextPath());
		Article article = null;
		try {
			article = articleService.getArticle(articleId);
		} catch (CmsServiceException e) {

			logger.info(e.getMessage());
		}
		model.addAttribute("article", article);
		ArticleComment ac = new ArticleComment();
		ArticleDto articleDto = new ArticleDto();
		ac.setArticle(new Article());
		model.addAttribute("articleComment", ac);
		model.addAttribute("edit", true);
		model.addAttribute("articleNew", articleDto);
		model.addAttribute("baseUrl", getBaseURL(request));
		return "viewArticle";
	}

	@Override
	public void setServletContext(ServletContext arg0) {
		sc = arg0;

	}

	public static final String PARAM_BASE_URL = "baseURL";

	// get base URL
	public String getBaseURL(HttpServletRequest request) {
		return request.getScheme() + "://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath();
	}

	@RequestMapping(value = "updateArticle", method = RequestMethod.GET)
	public String editArticles(Model model, HttpServletRequest request) {
		String updatedName = request.getParameter("updatedName");
		String updatedDescription = request.getParameter("updatedDescription");
		int articleId = Integer.parseInt(request.getParameter("articleId"));
		Article article = null;
		try {
			articleService.updateArticle(articleId, updatedName,
					updatedDescription);
			article = articleService.getArticle(articleId);
			model.addAttribute("updateSuccess", "Article updated Successfully!");
		} catch (CmsServiceException e) {
			model.addAttribute("updateFailed",
					"Something went wrong, Please try Again later!");
		}
		model.addAttribute("updated", "Article updated Sucessfully!");

		model.addAttribute("article", article);
		ArticleComment ac = new ArticleComment();
		ArticleDto articleDto = new ArticleDto();
		ac.setArticle(new Article());
		model.addAttribute("articleComment", ac);
		model.addAttribute("articleNew", articleDto);
		model.addAttribute("edit", true);
		model.addAttribute("baseUrl", getBaseURL(request));

		return "viewArticle";
	}

	@RequestMapping(value = "deleteArticle/{id}")
	public String deleteArticles(Model model, @PathVariable("id") int articleId) {
		logger.debug(sc.getContextPath());
		List<Article> list = null;
		try {
			articleService.deleteArticle(articleId);
			list = articleService.getArticles();
		} catch (CmsServiceException e) {
			logger.error("exception occured" + e.getMessage());
		}

		model.addAttribute("list", list);
		model.addAttribute("deleteMessage", "deleted successfully!");
		return "viewArticles";
	}

	@RequestMapping(value = "commentArticle", method= RequestMethod.POST)
	public String postComment(Model model, HttpServletRequest request) {
		Date postingDate = new Date();
		int articleId = Integer.parseInt(request.getParameter("articleId"));
		String comment = request.getParameter("comment");
		ArticleComment articleComment = new ArticleComment();
		articleComment.setCommentDesc(comment);
		articleComment.setCreatedDate(postingDate);
		Article article = null;
		try {
			articleService.saveComment(articleComment, articleId);
			article = articleService.getArticle(articleId);
		} catch (CmsServiceException e) {
			logger.error(e.getMessage());
		}

		model.addAttribute("baseUrl", getBaseURL(request));

		model.addAttribute("article", article);

		return "viewArticle";
	}
}
