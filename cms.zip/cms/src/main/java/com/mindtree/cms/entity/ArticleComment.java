package com.mindtree.cms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
/**
 * 
 * @author Sumit Verma
 *
 */
@Entity
public class ArticleComment {

	private int commentId;
	private String commentDesc;
	private Article article;
	private Date createdDate;

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the commentId
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getCommentId() {
		return commentId;
	}

	/**
	 * @param commentId
	 *            the commentId to set
	 */
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	/**
	 * @return the commentDesc
	 */
	@Column(length = 2255)
	public String getCommentDesc() {
		return commentDesc;
	}

	/**
	 * @param commentDesc
	 *            the commentDesc to set
	 */
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}

	@ManyToOne
	@JoinColumn(name = "ARTICLE_ID")
	public Article getArticle() {
		return this.article;
	}

	/**
	 * @param article
	 *            the article to set
	 */
	public void setArticle(Article article) {
		this.article = article;
	}
}
