/**
 * 
 */
package com.mindtree.cms.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * @author Sumit Verma
 *
 */
@Entity
public class Article {

	private int articleId;

	/**
	 * @return the articleComments
	 */
	@OneToMany(mappedBy = "article", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public List<ArticleComment> getArticleComments() {
		return articleComments;
	}

	/**
	 * @param articleComments
	 *            the articleComments to set
	 */
	public void setArticleComments(List<ArticleComment> articleComments) {
		this.articleComments = articleComments;
	}

	private String articleName;
	private String description;
	private Date createdDate;
	private List<ArticleAttachment> files = new ArrayList<ArticleAttachment>();
	private List<ArticleComment> articleComments = new ArrayList<ArticleComment>();
	private String uploadedBy;

	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return this.uploadedBy;
	}

	/**
	 * @param uploadedBy
	 *            the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	/**
	 * @return the files
	 */
	@OneToMany(mappedBy = "article", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	public List<ArticleAttachment> getFiles() {
		return this.files;
	}

	/**
	 * @param files
	 *            the files to set
	 */
	public void setFiles(List<ArticleAttachment> files) {
		this.files = files;
	}

	/**
	 * @return the articleId
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getArticleId() {
		return this.articleId;
	}

	/**
	 * @param articleId
	 *            the articleId to set
	 */
	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}

	/**
	 * @return the articleName
	 */
	public String getArticleName() {
		return this.articleName;
	}

	/**
	 * @param articleName
	 *            the articleName to set
	 */
	public void setArticleName(String articleName) {
		this.articleName = articleName;
	}

	/**
	 * @return the description
	 */
	@Column(length = 2255)
	public String getDescription() {
		return this.description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
