/**
 * 
 */
package com.mindtree.cms.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author Sumit Verma
 *  Util to upload file .
 */
@Component
public class CmsFileUploadUtil {

	/**
	 * @param cmsFiles
	 * @param filePath
	 * @param rootPath
	 */
	public List<String> saveFiles(List<MultipartFile> cmsFiles,
			List<String> filePath, String rootPath) {
		File dir = new File(rootPath + File.separator + "resources");
		if (!dir.exists())
			dir.mkdirs();

		if (null != cmsFiles && cmsFiles.size() > 0) {
			String finalPath = "";
			for (MultipartFile multipartFile : cmsFiles) {

				String fileName = multipartFile.getOriginalFilename();
				if (!"".equalsIgnoreCase(fileName)) {
					// Handle file content - multipartFile.getInputStream()
					try {
						finalPath = dir.getAbsolutePath() + File.separator
								+ fileName;
						multipartFile.transferTo(new File(finalPath));
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					filePath.add(fileName);
				}
			}

		}
		return filePath;
	}

}
