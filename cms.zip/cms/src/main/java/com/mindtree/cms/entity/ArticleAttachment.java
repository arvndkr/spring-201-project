/**
 * 
 */
package com.mindtree.cms.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * @author Sumit Verma
 *
 */
@Entity
public class ArticleAttachment {

	private int fileId;
	private String filePath;
	private Article article;

	/**
	 * @return the fileId
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getFileId() {
		return this.fileId;
	}

	/**
	 * @param fileId
	 *            the fileId to set
	 */
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return this.filePath;
	}

	/**
	 * @param filePath
	 *            the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return the article
	 */

	@ManyToOne
	@JoinColumn(name = "ARTICLE_ID")
	public Article getArticle() {
		return this.article;
	}

	/**
	 * @param article
	 *            the article to set
	 */
	public void setArticle(Article article) {
		this.article = article;
	}

}
