/**
 * 
 */
package com.mindtree.cms.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cms.constant.CmsWebConstants;
import com.mindtree.cms.dao.ArticleDao;
import com.mindtree.cms.dto.ArticleDto;
import com.mindtree.cms.entity.Article;
import com.mindtree.cms.entity.ArticleComment;
import com.mindtree.cms.exception.CmsDaoException;
import com.mindtree.cms.exception.CmsServiceException;
import com.mindtree.cms.service.ArticleService;

/**
 * @author Sumit Verma
 *
 */
@Service
public class ArticleServiceImpl implements ArticleService {
	/**
	 * articleDao dependency injection
	 */

	@Autowired
	private ArticleDao articleDao;

	/**
	 * this will save article.
	 */
	@Override
	public boolean saveArticle(ArticleDto dto, List<String> filePaths)
			throws CmsServiceException {
		boolean flag= false;
		if (dto != CmsWebConstants.NULL && filePaths.size() > 0) {

			try {
				articleDao.saveArticle(dto, filePaths);
				flag = true;
			} catch (CmsDaoException e) {
				throw new CmsServiceException(e.getMessage(), e);
			}
		}
		return flag;
	}

	/**
	 * this will give articles list.
	 */
	@Override
	public List<Article> getArticles() throws CmsServiceException {

		try {
			return articleDao.getArticles();
		} catch (CmsDaoException e) {
			throw new CmsServiceException("could not get articles", e);

		}

	}

	/**
	 * this will give detail of specific article.
	 */
	@Override
	public Article getArticle(int articleId) throws CmsServiceException {
		try {
			return articleDao.getArticle(articleId);
		} catch (CmsDaoException e) {
			throw new CmsServiceException(
					"Service excpetion in getting article details", e);
		}
	}

	/**
	 * this will delete article.
	 */
	@Override
	public void deleteArticle(int articleId) throws CmsServiceException {

		try {
			articleDao.deleteArticle(articleId);
		} catch (CmsDaoException e) {

			throw new CmsServiceException(e.getMessage(), e);
		}

	}

	/**
	 * this will save article's comments.
	 */
	@Override
	public void saveComment(ArticleComment comment, int articleId)
			throws CmsServiceException {
		try {
			articleDao.saveComment(comment, articleId);
		} catch (CmsDaoException e) {

			throw new CmsServiceException(e.getMessage());
		}

	}

	/**
	 * this will update article detail, name and description.
	 */
	@Override
	public void updateArticle(int articleId, String updatedName,
			String updatedDescription) throws CmsServiceException {
		try {
			articleDao
					.updateArticle(articleId, updatedName, updatedDescription);
		} catch (CmsDaoException e) {
			throw new CmsServiceException(e.getMessage(), e);
		}

	}

}
