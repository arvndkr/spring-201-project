/**
 * 
 */
package com.mindtree.cms.service;

import java.util.List;

import com.mindtree.cms.dto.ArticleDto;
import com.mindtree.cms.entity.Article;
import com.mindtree.cms.entity.ArticleComment;
import com.mindtree.cms.exception.CmsServiceException;

/**
 * @author Sumit Verma
 *
 */
public interface ArticleService {

	/**
	 * to save article.
	 * 
	 * @param dto
	 * @param filePaths
	 * @throws CmsServiceException
	 */
	boolean saveArticle(ArticleDto dto, List<String> filePaths)
			throws CmsServiceException;

	/**
	 * to get artiicle lists.
	 * 
	 * @return
	 * @throws CmsServiceException
	 */
	List<Article> getArticles() throws CmsServiceException;

	/**
	 * to get specific article.
	 * 
	 * @param articleId
	 * @return
	 * @throws CmsServiceException
	 */
	Article getArticle(int articleId) throws CmsServiceException;

	/**
	 * to delete article.
	 * 
	 * @param articleId
	 * @throws CmsServiceException
	 */
	void deleteArticle(int articleId) throws CmsServiceException;

	/**
	 * to save comment.
	 * 
	 * @param comment
	 * @param articleId
	 * @throws CmsServiceException
	 */
	void saveComment(ArticleComment comment, int articleId)
			throws CmsServiceException;

	/**
	 * to update article.
	 * 
	 * @param articleId
	 * @param updatedName
	 * @param updatedDescription
	 * @throws CmsServiceException
	 */
	void updateArticle(int articleId, String updatedName,
			String updatedDescription) throws CmsServiceException;

}
