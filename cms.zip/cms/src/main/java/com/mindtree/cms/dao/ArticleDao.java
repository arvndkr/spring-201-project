/**
 * 
 */
package com.mindtree.cms.dao;

import java.util.List;

import com.mindtree.cms.dto.ArticleDto;
import com.mindtree.cms.entity.Article;
import com.mindtree.cms.entity.ArticleComment;
import com.mindtree.cms.exception.CmsDaoException;

/**
 * @author Sumit Verma
 *
 */
public interface ArticleDao {

	/**
	 * to save article.
	 * 
	 * @param dto
	 * @param filePaths
	 * @throws CmsDaoException
	 */
	boolean saveArticle(ArticleDto dto, List<String> filePaths)
			throws CmsDaoException;

	/**
	 * to get articles.
	 * 
	 * @return
	 * @throws CmsDaoException
	 */
	List<Article> getArticles() throws CmsDaoException;

	/**
	 * to get specific article details.
	 * 
	 * @param articleId
	 * @return
	 * @throws CmsDaoException
	 */
	Article getArticle(int articleId) throws CmsDaoException;

	/**
	 * to delete one article.
	 * 
	 * @param articleId
	 * @throws CmsDaoException
	 */
	void deleteArticle(int articleId) throws CmsDaoException;

	/**
	 * to save comment.
	 * 
	 * @param comment
	 * @param articleId
	 * @throws CmsDaoException
	 */
	void saveComment(ArticleComment comment, int articleId)
			throws CmsDaoException;

	/**
	 * to save comments.
	 * 
	 * @param articleId
	 * @param updatedName
	 * @param updatedDescription
	 * @throws CmsDaoException
	 */
	void updateArticle(int articleId, String updatedName,
			String updatedDescription) throws CmsDaoException;
}
