/**
 * 
 */
package com.mindtree.cms.exception;

/**
 * @author Sumit Verma
 *
 */
public class CmsDaoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public CmsDaoException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CmsDaoException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public CmsDaoException(String message) {
		super(message);
	}

}
