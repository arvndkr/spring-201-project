/**
 * 
 */
package com.mindtree.cms.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author Sumit Verma 
 * this is the util to create session factory .
 */
@Repository
public class CmsHibernateUtil {

	/**
	 * @return the factory
	 */
	public SessionFactory getFactory() {
		return this.sessionFactory1;
	}

	/**
	 * @param factory
	 *            the factory to set
	 */
	public void setFactory(SessionFactory factory) {
		this.sessionFactory1 = factory;
	}

	@Autowired
	private SessionFactory sessionFactory1;

	protected Session getSession() {

		Session session = null;
		if (session == null) {

			session = sessionFactory1.openSession();
		}
		return session;
	}

}
