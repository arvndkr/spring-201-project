/**
 * 
 */
/**
 * @author Sumit Verma
 *
 */
package com.mindtree.cms.exception;