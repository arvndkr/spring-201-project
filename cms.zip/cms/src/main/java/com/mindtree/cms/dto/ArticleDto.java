/**
 * 
 */
package com.mindtree.cms.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mindtree.cms.entity.ArticleComment;

/**
 * @author Sumit Verma
 *
 */
public class ArticleDto {

	private List<MultipartFile> multipleAttachement;

	private List<ArticleComment> comments;

	/**
	 * @return the comments
	 */
	public List<ArticleComment> getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(List<ArticleComment> comments) {
		this.comments = comments;
	}

	private List<String> fileNames;

	private String image;

	private String document;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	/**
	 * @return the fileNames
	 */
	public List<String> getFileNames() {
		return this.fileNames;
	}

	/**
	 * @param fileNames
	 *            the fileNames to set
	 */
	public void setFileNames(List<String> fileNames) {
		this.fileNames = fileNames;
	}

	private String articleName;

	/**
	 * @return the articleName
	 */
	public String getArticleName() {
		return this.articleName;
	}

	/**
	 * @param articleName
	 *            the articleName to set
	 */
	public void setArticleName(String articleName) {
		this.articleName = articleName;
	}

	/**
	 * @return the articleDescription
	 */
	public String getArticleDescription() {
		return this.articleDescription;
	}

	/**
	 * @param articleDescription
	 *            the articleDescription to set
	 */
	public void setArticleDescription(String articleDescription) {
		this.articleDescription = articleDescription;
	}

	/**
	 * @return the articleComments
	 */
	public String getArticleComments() {
		return this.articleComments;
	}

	/**
	 * @param articleComments
	 *            the articleComments to set
	 */
	public void setArticleComments(String articleComments) {
		this.articleComments = articleComments;
	}

	private String articleDescription;

	private String articleComments;

	private Date createdDate;

	private String createdBy;

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.articleName;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.articleName = name;
	}

	/**
	 * @return the multipleAttachement
	 */
	public List<MultipartFile> getMultipleAttachement() {
		return this.multipleAttachement;
	}

	/**
	 * @param multipleAttachement
	 *            the multipleAttachement to set
	 */
	public void setMultipleAttachement(List<MultipartFile> multipleAttachement) {
		this.multipleAttachement = multipleAttachement;
	}

}
