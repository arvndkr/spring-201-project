$(document).ready(function(){
	$("#hotelsDetails").hide();
	$("#noDataFound").hide();
	 $("#cityViewHotels").change(function(){
	  	  $.ajax({
	  		  url: "/fetchLowPricedHotels",
	  		  data:{
	  			  cityId : $("#cityViewHotels").val()
	  		  },
	  		  success: function(data){
	  			  if(data == "No Data Found"){
	  				$("#hotelsDetails").hide();
	  				$("#noDataFound").show();
	  			  }else{
	  				$("#noDataFound").hide();
	  			  var jsonObj = JSON.parse(data);
	  			$('#tableBody').html("");
	  			  jQuery.each(jsonObj, function(i, hotel) {
	  				  $('#tableBody').append("<tr><td>"+hotel.hotelName+"</td><td>"+hotel.rent+"</td><td>"+hotel.numberOfRooms+"</td><td>"+hotel.rating+"</td></tr>");
	  				});
	  			$("#hotelsDetails").show();
	  			  }
	  			
	  			  
	  			/*$('#hotelsDetails').append("</tbody></table>");*/
	  	/*		  $("#hotelsDropdown").html("");
	  			  $("#hotelsDropdown").html(data);
	  			  $("#hotelsDropdown option").each(function(i){
	  				  if($(this).val() == ""){
	  					  $(this).remove();
	  				  }
	  			    });*/
	        }});
	  });
	    
	    $("#cancel").click(function(){
	    	window.location.replace("/home");
	    });
	
});