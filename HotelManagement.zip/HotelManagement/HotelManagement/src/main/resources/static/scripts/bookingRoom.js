$(document).ready(function(){
	$("#dateValidation").hide();
	$(".fromDatepickerHidden").val("");
	$(".toDatepickerHidden").val("");
    $("#city").change(function(){
    	  $.ajax({
    		  url: "/fetchCityRelatedHotels",
    		  data:{
    			  cityId : $("#city").val()
    		  },
    		  success: function(data){
    			  /*var jsonObj = JSON.parse(data);
    			  alert(jsonObj);
    			  jQuery.each(jsonObj, function(i, hotel) {
    				  $('#hotelsDropdown').append("<option value='"+hotel.hotelId+"'>"+hotel.hotelName+"</option>");
    				});*/
    			  $("#hotelsDropdown").html("");
    			  $("#hotelsDropdown").html(data);
    			  $("#hotelsDropdown option").each(function(i){
    				  if($(this).val() == ""){
    					  $(this).remove();
    				  }
    			    });
          }});
    });
    
    $(".fromDatepicker,.toDatepicker").datepicker({
    	  onSelect: function() {
    		  $("#dateValidation").hide();
    		  var fromDate = null;
    		  var toDate = null;
    		  if($(".fromDatepicker").val() != ""){
    			  fromDate = new Date($(".fromDatepicker").val());
    			  $(".fromDatepickerHidden").val($(".fromDatepicker").val());
    			  
    		  }
    		  
    		  if($(".toDatepicker").val() != ""){
    			  toDate = new Date($(".toDatepicker").val());
    			  $(".toDatepickerHidden").val($(".toDatepicker").val())
    		  }
    		  
    		  if((fromDate != null) && (toDate != null) && (toDate < fromDate)){
    			  $("#dateValidation").show();
    			  $(".fromDatepicker").val("");
    			  $(".fromDatepickerHidden").val("");
    			  $(".toDatepickerHidden").val("");
    			  $(".toDatepicker").val("");
    			/*  alert("todate should be > fromDate");*/
    		  }
    	  }
    	});
    
    $("#cityViewHotels").change(function(){
  	  $.ajax({
  		  url: "/fetchLowPricedHotels",
  		  data:{
  			  cityId : $("#cityViewHotels").val()
  		  },
  		  success: function(data){
  			  if(data == "No Data Found"){
  				$("#hotelsDetails").hide();
  				$("#noDataFound").show();
  			  }else{
  				$("#noDataFound").hide();
  			  var jsonObj = JSON.parse(data);
  			$('#tableBody').html("");
  			  jQuery.each(jsonObj, function(i, hotel) {
  				  $('#tableBody').append("<tr><td>"+hotel.hotelName+"</td><td>"+hotel.rent+"</td><td>"+hotel.numberOfRooms+"</td><td>"+hotel.rating+"</td></tr>");
  				});
  			$("#hotelsDetails").show();
  			  }
  			
  			  
  			/*$('#hotelsDetails').append("</tbody></table>");*/
  	/*		  $("#hotelsDropdown").html("");
  			  $("#hotelsDropdown").html(data);
  			  $("#hotelsDropdown option").each(function(i){
  				  if($(this).val() == ""){
  					  $(this).remove();
  				  }
  			    });*/
        }});
  });
    
    $("#cancel").click(function(){
    	window.location.replace("/home");
    });
  
});