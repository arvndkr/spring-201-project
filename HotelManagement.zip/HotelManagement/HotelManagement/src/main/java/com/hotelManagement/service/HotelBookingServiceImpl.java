/**
 * 
 */
package com.hotelManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.dao.HotelBookingDao;
import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.exception.HotelBookingDaoException;
import com.hotelManagement.exception.HotelBookingServiceException;

/**
 * @author Gaurav
 *
 */
@Service
public class HotelBookingServiceImpl implements HotelBookingService {
	
	@Autowired
	private HotelBookingDao hotelBookingDao;
	
	
	/* (non-Javadoc)
	 * @see com.hotelManagement.service.HotelBookingService#fetchHotels(int)
	 */
	@Override
	public List<Hotel> fetchHotels(int cityId) throws HotelBookingServiceException{
		try {
			return hotelBookingDao.fetchHotels(cityId);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}

	@Override
	public Hotel fetchHotelById(int hotelId) throws HotelBookingServiceException{
		try {
			return hotelBookingDao.fetchHotelById(hotelId);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}
	
	@Override
	public double saveBooking(HotelBookingDto bookingDto) throws HotelBookingServiceException{
		try {
			return hotelBookingDao.saveBooking(bookingDto);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}
	
	@Override
	public boolean isRoomAvailableForHotel(HotelBookingDto hotelBookingDto) throws HotelBookingServiceException{
		try {
			return hotelBookingDao.isRoomAvailableForHotel(hotelBookingDto);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}
	
	@Override
	public List<Hotel> fetchLowPricedHotels(int cityId) throws HotelBookingServiceException{
		try {
			return hotelBookingDao.fetchLowPricedHotels(cityId);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}

}
