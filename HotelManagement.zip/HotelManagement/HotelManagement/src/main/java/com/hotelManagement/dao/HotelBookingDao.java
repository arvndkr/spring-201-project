package com.hotelManagement.dao;

import java.util.List;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.exception.HotelBookingDaoException;

/**
 * Interface for HotelBookingDaoImpl
 * @author Gaurav
 *
 */
public interface HotelBookingDao {

	/**
	 * 
	 * @param cityId
	 * @return
	 * @throws HotelBookingDaoException 
	 */
	List<Hotel> fetchHotels(int cityId) throws HotelBookingDaoException;

	/**
	 * 
	 * @param hotelId
	 * @return
	 * @throws HotelBookingDaoException 
	 */
	Hotel fetchHotelById(int hotelId) throws HotelBookingDaoException;

	/**
	 * 
	 * @param bookingDto
	 * @return
	 * @throws HotelBookingDaoException 
	 */
	double saveBooking(HotelBookingDto bookingDto) throws HotelBookingDaoException;

	/**
	 * 
	 * @param hotelBookingDto
	 * @return
	 * @throws HotelBookingDaoException 
	 */
	boolean isRoomAvailableForHotel(HotelBookingDto hotelBookingDto) throws HotelBookingDaoException;

	/**
	 * 
	 * @param cityId
	 * @return
	 * @throws HotelBookingDaoException 
	 */
	List<Hotel> fetchLowPricedHotels(int cityId) throws HotelBookingDaoException;

}