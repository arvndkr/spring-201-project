/**
 * 
 */
package com.hotelManagement.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Booking;
import com.hotelManagement.entity.City;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.entity.User;
import com.hotelManagement.exception.HotelBookingDaoException;

/**
 * This class interacts with DB for all booking related requests.
 * @author Gaurav
 *
 */
@Repository
public class HotelBookingDaoImpl implements HotelBookingDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private UserDao userDaoImpl;
	
	
	/* (non-Javadoc)
	 * @see com.hotelManagement.dao.HotelBookingDao#fetchHotels(int)
	 */
	@Override
	public List<Hotel> fetchHotels(int cityId) throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		List<Hotel> hotels = new ArrayList<Hotel>();
		try{
			City city = new City();/*(City) session.load(City.class, new Integer(cityId));*/
			city.setCityId(cityId);
			hotels = session.createQuery("from Hotel hotel where hotel.city=:city").setParameter("city", city).list();
			for(Hotel hotel : hotels){
				Hibernate.initialize(hotel.getCity());
			}
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
			session.close();
			}
		}
		
		return hotels;
	}
	
	/**
	 * This method fetches hotel by hotelId
	 * @throws HotelBookingDaoException 
	 */
	@Override
	public Hotel fetchHotelById(int hotelId) throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		Hotel hotel = null;
		try{
			hotel = (Hotel) session.load(Hotel.class, new Integer(hotelId));
			Hibernate.initialize(hotel.getCity());
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
			session.close();
			}
		}
		return hotel;
	}
	
	@Override
	public double saveBooking(HotelBookingDto bookingDto) throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		Booking booking = new Booking();
		double amount = 0;
		try{
			/*User user = session.load(User.class, bookingDto.get)*/
			City city = (City) session.load(City.class, new Integer(bookingDto.getCityId()));
			Hotel hotel = (Hotel) session.load(Hotel.class, new Integer(bookingDto.getHotelId()));
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date fromDate = null;
			Date toDate = null;
			try {
				fromDate = dateFormat.parse(bookingDto.getFromDate());
				toDate = dateFormat.parse(bookingDto.getToDate());
			} catch (ParseException e) {
				throw new HotelBookingDaoException(e);
			}
			User user = userDaoImpl.fetchUserByName(bookingDto.getUserName());
			amount = Integer.parseInt(bookingDto.getNoOfRooms().trim()) * hotel.getRent();
			booking.setAmount(amount);
			booking.setCheckInDate(fromDate);
			booking.setCheckOutDate(toDate);
			booking.setCity(city);
			booking.setHotel(hotel);
			booking.setNoOfRooms(Integer.parseInt(bookingDto.getNoOfRooms().trim()));
			booking.setRefId(bookingDto.getRefId());
			booking.setUser(user);
			/*throw new RuntimeException();*/
			session.save(booking);
			session.flush();
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
				session.close();
			}
		}
		return amount;
	}
	
	@Override
	public boolean isRoomAvailableForHotel(HotelBookingDto hotelBookingDto) throws HotelBookingDaoException{
		Hotel hotel = fetchHotelById(hotelBookingDto.getHotelId());
		Session session = sessionFactory.openSession();
		boolean flag= false;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date fromDate = null;
		Date toDate = null;
		try {
			fromDate = dateFormat.parse(hotelBookingDto.getFromDate());
			toDate = dateFormat.parse(hotelBookingDto.getToDate());
		} catch (ParseException e) {
			throw new HotelBookingDaoException(e);
		}
		try{
			List<Booking> bookings = session.createQuery("from Booking booking where booking.hotel=:hotel and ((booking.checkInDate BETWEEN :fromDate AND :toDate) OR (booking.checkOutDate BETWEEN :fromDate AND :toDate))").setParameter("hotel", hotel).setParameter("fromDate", fromDate).setParameter("toDate", toDate).list();
			int roomsBooked = 0;
			for(Booking booking : bookings){
				roomsBooked = roomsBooked + booking.getNoOfRooms();
			}
			int roomsAvail = hotel.getNumberOfRooms() - roomsBooked;
			if(roomsAvail > 0){
				if(roomsAvail>=Integer.parseInt(hotelBookingDto.getNoOfRooms().trim())){
					flag = true;
				}
			}
			/*Hibernate.initialize(hotel.getCity());*/
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
			session.close();
			}
		}
		
		return flag;
	}
	
	@Override
	public List<Hotel> fetchLowPricedHotels(int cityId) throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		List<Hotel> hotels = new ArrayList<Hotel>();
		try{
			City city = new City();/*(City) session.load(City.class, new Integer(cityId));*/
			city.setCityId(cityId);
			hotels = session.createQuery("from Hotel hotel where hotel.city=:city order by hotel.rent").setParameter("city", city).setMaxResults(5).list();
			for(Hotel hotel : hotels){
				Hibernate.initialize(hotel.getCity());
			}
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
			session.close();
			}
		}
		
		return hotels;
	}

}
