package com.hotelManagement.service;

import java.util.List;

import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.entity.City;
import com.hotelManagement.entity.User;
import com.hotelManagement.exception.HotelBookingServiceException;

public interface UserRegistrationService {

	List<City> fetchAllCities() throws HotelBookingServiceException;

	void submitRegistration(UserRegistrationDto userRegistrationDto) throws HotelBookingServiceException;
	
	User fetchUserByUserName(String userName);

}