/**
 * 
 */
package com.hotelManagement.validator;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.exception.HotelBookingServiceException;
import com.hotelManagement.service.HotelBookingService;

/**
 * @author Gaurav
 *
 */
@Component
public class HotelBookingValidator implements Validator{

	@Autowired
	private HotelBookingService hotelBookingService;
	
	@Override
	public boolean supports(Class<?> arg0) {
		return HotelBookingDto.class.equals(arg0);
	}

	@Override
	public void validate(Object arg0, Errors errors) {
		HotelBookingDto hotelBookingDto = (HotelBookingDto) arg0;
		int maxRooms = 0;
		if(hotelBookingDto.getHotelId() > 0){
			try {
				maxRooms = hotelBookingService.fetchHotelById(hotelBookingDto.getHotelId()).getNumberOfRooms();
			} catch (HotelBookingServiceException e) {
				System.out.println("Exception occured");
			}
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"fromDate","valid.fromDate");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"toDate","valid.toDate");
		if(hotelBookingDto.getCityId()<1){
			errors.rejectValue("cityId", "valid.cityId");
		}
		if(hotelBookingDto.getHotelId()<1){
			errors.rejectValue("hotelId", "valid.hotelId");
		}
		if(hotelBookingDto.getNoOfRooms().isEmpty()){
			errors.rejectValue("noOfRooms", "valid.noOfRooms");			
		}else if(StringUtils.isBlank(hotelBookingDto.getNoOfRooms())){
			errors.rejectValue("noOfRooms", "valid.noOfRooms.Blank");
		}else if(!StringUtils.isNumeric(hotelBookingDto.getNoOfRooms().trim())){
			errors.rejectValue("noOfRooms", "valid.noOfRooms.Numeric");
		}else if((hotelBookingDto.getHotelId() > 0) && (Integer.parseInt(hotelBookingDto.getNoOfRooms().trim()) > maxRooms)){
			errors.rejectValue("noOfRooms", "valid.noOfRooms.MaxExceed");
		} else
			try {
				if((!hotelBookingDto.getFromDate().isEmpty()) && (!hotelBookingDto.getToDate().isEmpty()) && (hotelBookingDto.getHotelId() > 0) && (!hotelBookingService.isRoomAvailableForHotel(hotelBookingDto))){
					errors.rejectValue("noOfRooms", "valid.noOfRooms.NotAvailable");
				}
			} catch (HotelBookingServiceException e) {
				System.out.println("exception occured while checking rooms availability");
			}
	}

}
