/**
 * 
 */
package com.hotelManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.dao.UserDao;
import com.hotelManagement.dao.UserRegistrationDao;
import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.entity.City;
import com.hotelManagement.entity.User;
import com.hotelManagement.exception.HotelBookingDaoException;
import com.hotelManagement.exception.HotelBookingServiceException;

/**
 * @author Gaurav
 *
 */
@Service
public class UserRegistrationSeviceImpl implements UserRegistrationService {

	@Autowired
	private UserRegistrationDao userRegistrationDao;
	
	@Autowired
	private UserDao userDaoImpl;
	
	/* (non-Javadoc)
	 * @see com.hotelManagement.service.UserRegistrationService#fetchAllCities()
	 */
	@Override
	public List<City> fetchAllCities() throws HotelBookingServiceException{
		try {
			return userRegistrationDao.fetchAllCities();
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}
	
	@Override
	public void submitRegistration(UserRegistrationDto userRegistrationDto) throws HotelBookingServiceException{
		try {
			userRegistrationDao.submitRegistration(userRegistrationDto);
		} catch (HotelBookingDaoException e) {
			throw new HotelBookingServiceException(e);
		}
	}
	
	@Override
	public User fetchUserByUserName(String userName){
		return userDaoImpl.fetchUserByName(userName);
	}

}
