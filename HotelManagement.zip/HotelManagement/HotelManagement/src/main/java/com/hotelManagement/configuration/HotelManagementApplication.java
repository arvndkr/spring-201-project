package com.hotelManagement.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
/**
 * This is main class 
 * @author Gaurav
 *
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.hotelManagement.*")
public class HotelManagementApplication extends SpringBootServletInitializer {

	 @Override
	    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	        return application.sources(HotelManagementApplication.class);
	    }
	
	public static void main(String[] args) {
		SpringApplication.run(HotelManagementApplication.class, args);
	}
}
