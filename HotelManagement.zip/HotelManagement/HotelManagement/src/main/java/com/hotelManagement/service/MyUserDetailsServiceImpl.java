/**
 * 
 */
package com.hotelManagement.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hotelManagement.dao.UserDao;
import com.hotelManagement.entity.User;
import com.hotelManagement.entity.UserRole;


/**
 * @author Gaurav
 *
 */
@Service("userDetailsService")
public class MyUserDetailsServiceImpl implements UserDetailsService{

	@Autowired
	private UserDao userDaoImpl;
	
	@Transactional(readOnly=true)
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		System.out.println("------------UserDetailsService DAO loadUserByUsername-----------"+userName);
		User user = userDaoImpl.fetchUserByName(userName);
		System.out.println("----"+user.getUserName()+" "+user.getPassword()+" "+user.getUserRole().getRole());
		List<GrantedAuthority> authorities = buildUserAuthority(user.getUserRole());
		return buildUserForAuthentication(user, authorities);
	}

	private org.springframework.security.core.userdetails.User buildUserForAuthentication(User user,
			List<GrantedAuthority> authorities) {
			return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(),
				true, true, true, true, authorities);
		}
	
	private List<GrantedAuthority> buildUserAuthority(UserRole userRole) {
		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		setAuths.add(new SimpleGrantedAuthority("ROLE_"+userRole.getRole().toUpperCase()));
		List<GrantedAuthority> result = new ArrayList<GrantedAuthority>(setAuths);
		return result;
	}

}
