package com.hotelManagement.dao;

import com.hotelManagement.entity.User;

public interface UserDao {

	User fetchUserByName(String userName);

}