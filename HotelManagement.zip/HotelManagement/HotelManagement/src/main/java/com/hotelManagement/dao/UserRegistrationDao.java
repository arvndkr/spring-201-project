package com.hotelManagement.dao;

import java.util.List;

import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.entity.City;
import com.hotelManagement.exception.HotelBookingDaoException;

public interface UserRegistrationDao {

	List<City> fetchAllCities() throws HotelBookingDaoException;

	void submitRegistration(UserRegistrationDto userRegistrationDto) throws HotelBookingDaoException;

}