/**
 * 
 */
package com.hotelManagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.exception.HotelBookingServiceException;
import com.hotelManagement.service.HotelBookingService;
import com.hotelManagement.service.UserRegistrationService;

/**
 * This class handles all the requests from Home page.
 * @author Gaurav
 *
 */
@Controller
public class HomeController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private UserRegistrationService userRegistrationervice;
	

	/**
	 * This method redirects to booking page.
	 * @param model
	 * @return
	 */
	@RequestMapping("/booking")
	public ModelAndView home(Model model) {
		logger.info("--Accessing booking page--");
		model.addAttribute("hotelBookingDto",new HotelBookingDto());
		try {
			model.addAttribute("cities",userRegistrationervice.fetchAllCities());
		} catch (HotelBookingServiceException e) {
			logger.error("## error occured while fetching cities ##");
			return new ModelAndView("exception");
		}
		return new ModelAndView("booking");
	}
	
	/**
	 * This method redirects to ViewLowestPriceHotels page.
	 * @param model
	 * @return
	 */
	@RequestMapping("/ViewLowestPriceHotels")
	public ModelAndView viewLowestPriceHotels(Model model) {
		try {
			model.addAttribute("cities",userRegistrationervice.fetchAllCities());
		} catch (HotelBookingServiceException e) {
			logger.error("## error occured while fetching cities ##");
			return new ModelAndView("exception");
		}
		return new ModelAndView("lowPricesdHotels");
	}
	
	

}
