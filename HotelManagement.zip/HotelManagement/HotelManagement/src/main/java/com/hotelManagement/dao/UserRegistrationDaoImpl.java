/**
 * 
 */
package com.hotelManagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.entity.City;
import com.hotelManagement.entity.User;
import com.hotelManagement.entity.UserRole;
import com.hotelManagement.exception.HotelBookingDaoException;

/**
 * @author Gaurav
 *
 */
@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	/* (non-Javadoc)
	 * @see com.hotelManagement.dao.UserRegistrationDao#fetchAllCities()
	 */
	@Override
	public List<City> fetchAllCities() throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		List<City> cities = new ArrayList<City>();
		try{
		cities = session.createQuery("from City").list();
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			if(session.isOpen()){
			session.close();
			}
		}
		
		return cities;
	}
	
	@Override
	public void submitRegistration(UserRegistrationDto userRegistrationDto) throws HotelBookingDaoException{
		Session session = sessionFactory.openSession();
		try{
			City city = (City) session.load(City.class, new Integer(userRegistrationDto.getCityId()));
			UserRole userRole = (UserRole) session.load(UserRole.class, new Integer(1));
			User user = new User();
			user.setUserRole(userRole);
			user.setUserName(userRegistrationDto.getUserName().trim());
			user.setPassword(userRegistrationDto.getPassword().trim());
			user.setCity(city);
			session.save(user);
			session.flush();
		}catch(HibernateException ex){
			throw new HotelBookingDaoException(ex);
		}finally {
			session.close();
		}
		
	}
}
