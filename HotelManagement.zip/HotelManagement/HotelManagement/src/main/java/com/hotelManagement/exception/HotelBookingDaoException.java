/**
 * 
 */
package com.hotelManagement.exception;

/**
 * @author Gaurav
 *
 */
public class HotelBookingDaoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	public HotelBookingDaoException(){
		super();
	}
	
	/**
	 * 
	 * @param ex
	 */
	public HotelBookingDaoException(String ex){
		super(ex);
	}
	
	/**
	 * 
	 * @param ex
	 */
	public HotelBookingDaoException(Throwable ex){
		super(ex);
	}
	
	/**
	 * 
	 * @param msg
	 * @param ex
	 */
	public HotelBookingDaoException(String msg,Throwable ex){
		super(msg,ex);
	}
	
	

}
