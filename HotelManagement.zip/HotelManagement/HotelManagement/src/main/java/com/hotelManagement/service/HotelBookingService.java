package com.hotelManagement.service;

import java.util.List;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.exception.HotelBookingServiceException;

public interface HotelBookingService {

	List<Hotel> fetchHotels(int cityId) throws HotelBookingServiceException;

	Hotel fetchHotelById(int hotelId) throws HotelBookingServiceException;

	double saveBooking(HotelBookingDto bookingDto) throws HotelBookingServiceException;

	boolean isRoomAvailableForHotel(HotelBookingDto hotelBookingDto) throws HotelBookingServiceException;

	List<Hotel> fetchLowPricedHotels(int cityId) throws HotelBookingServiceException;

}