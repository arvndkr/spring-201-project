/**
 * 
 */
package com.hotelManagement.validator;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hotelManagement.dto.UserRegistrationDto;
import com.hotelManagement.entity.User;
import com.hotelManagement.service.UserRegistrationService;


/**
 * @author Gaurav
 *
 */
@Component
public class RegistrationValidator implements Validator{

	@Autowired
	private UserRegistrationService userRegService;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return UserRegistrationDto.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		UserRegistrationDto userRegistrationDto = (UserRegistrationDto) target;
		if((userRegistrationDto.getUserName() == null) || (userRegistrationDto.getUserName().isEmpty()) || (StringUtils.isBlank(userRegistrationDto.getUserName()))){
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"userName","valid.userName");
		}else if(org.apache.commons.lang3.StringUtils.isNumeric(userRegistrationDto.getUserName())){
			errors.rejectValue("userName", "valid.userName.NotNumeric");
		}else{
			User user = userRegService.fetchUserByUserName(userRegistrationDto.getUserName().trim());
			if(user != null){
				errors.rejectValue("userName", "valid.userName.AlreayExists");
			}
			
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,"password","valid.password");
		if(userRegistrationDto.getCityId()<1){
			errors.rejectValue("cityId", "valid.cityId");
		}
		
	}

}
