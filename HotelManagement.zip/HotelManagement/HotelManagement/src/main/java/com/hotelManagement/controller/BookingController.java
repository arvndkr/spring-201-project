/**
 * 
 */
package com.hotelManagement.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hotelManagement.dto.HotelBookingDto;
import com.hotelManagement.entity.Hotel;
import com.hotelManagement.exception.HotelBookingServiceException;
import com.hotelManagement.service.HotelBookingService;
import com.hotelManagement.service.UserRegistrationService;
import com.hotelManagement.validator.HotelBookingValidator;

/**
 * This class handles booking related requests.
 * @author Gaurav
 *
 */
@Controller
public class BookingController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private UserRegistrationService userRegistrationervice;
	
	@Autowired
	private HotelBookingService hotelBookingService;
	
	@Autowired
	private HotelBookingValidator hotelBookingValidator;
	

	/**
	 * Initbinder for HotelBookingValidator.
	 * @param binder
	 */
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(hotelBookingValidator);
	}

	/**
	 * This method fetches hotels based on city.
	 * @param cityId
	 * @param model
	 * @return
	 */
	@RequestMapping("/fetchCityRelatedHotels")
	public String fetchCityRelatedHotels(@RequestParam("cityId") String cityId, Model model) {
		List<Hotel> hotels = null;
		try {
			hotels = hotelBookingService.fetchHotels(Integer.parseInt(cityId));
			logger.info("--No of hotels fetched--"+hotels.size());
		} catch (NumberFormatException | HotelBookingServiceException e) {
			logger.error("## error occured while fetching city related hotels ##");
		}
		model.addAttribute("hotels", hotels);
		return "hotelDropdowns";
	}

	/**
	 * This method submit booking.s
	 * @param hotelBookingDto
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping("/submitBooking")
	public String submitBooking(@ModelAttribute("hotelBookingDto")@Validated HotelBookingDto hotelBookingDto,BindingResult bindingResult, Model model) {
	System.out.println(hotelBookingDto);
	if(bindingResult.hasErrors()){
		try {
			model.addAttribute("cities",userRegistrationervice.fetchAllCities());
		} catch (HotelBookingServiceException e) {
			logger.error("## error occured while fetching cities ##");
			return "exception";
		}
		return "booking";
	}
		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String refId = dateFormat.format(currentDate);
		System.out.println(refId);
		hotelBookingDto.setRefId(refId);
		User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		hotelBookingDto.setUserName(user.getUsername());
		double amount = 0;
		try {
			amount = hotelBookingService.saveBooking(hotelBookingDto);
			logger.info("--Total amount--"+amount);
		} catch (HotelBookingServiceException e) {
			logger.error("## error occured while saving booking ##");
			return "exception";
		}
		model.addAttribute("refId",refId);
		model.addAttribute("amount",amount);
		return "bookingConfirmation";
	}
	
	/**
	 * This method fetched 5 low priced hotels based on city.
	 * @param cityId
	 * @param model
	 * @return
	 */
	@RequestMapping("/fetchLowPricedHotels")
	@ResponseBody
	public String fetchLowPricedHotels(@RequestParam("cityId") String cityId, Model model) {
		ObjectMapper mapper = new ObjectMapper();
		List<Hotel> hotels = null;
		try {
			hotels = hotelBookingService.fetchLowPricedHotels(Integer.parseInt(cityId));
		} catch (NumberFormatException | HotelBookingServiceException e1) {
			logger.error("## error occured while fetching low priced hotels ##");
		}
		String hotelsJson = null;
		if(hotels != null && hotels.size()>0){
		try {
			 hotelsJson = mapper.writeValueAsString(hotels);
		} catch (IOException e) {
			logger.error("## error occured while forming json ##");
		}
		}else{
			hotelsJson = "No Data Found";
		}
		logger.info("--Json generated--"+hotelsJson);
		return hotelsJson;
	}

}
