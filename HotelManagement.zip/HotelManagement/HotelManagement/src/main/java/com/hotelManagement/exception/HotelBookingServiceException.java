/**
 * 
 */
package com.hotelManagement.exception;

/**
 * @author Gaurav
 *
 */
public class HotelBookingServiceException extends HotelBookingDaoException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public HotelBookingServiceException(){
		super();
	}
	
	/**
	 * 
	 * @param ex
	 */
	public HotelBookingServiceException(String ex){
		super(ex);
	}
	
	/**
	 * 
	 * @param ex
	 */
	public HotelBookingServiceException(Throwable ex){
		super(ex);
	}
	
	/**
	 * 
	 * @param msg
	 * @param ex
	 */
	public HotelBookingServiceException(String msg,Throwable ex){
		super(msg,ex);
	}

}
