/**
 * 
 */
package com.hotelManagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hotelManagement.entity.User;


/**
 * @author Gaurav
 *
 */
@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;

	/* (non-Javadoc)
	 * @see com.hotelManagement.dao.UserDao#fetchUserByName(java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public User fetchUserByName(String userName) {
		List<User> users = new ArrayList<User>();
		User user = null;
		Session session = sessionFactory.openSession();
		users = session.createQuery("from User where userName=:user").setParameter("user", userName).list();
		if(users.size()>0){
			user = users.get(0);
			Hibernate.initialize(user.getUserRole());
		}
		session.close();
		return user;

	}

}
